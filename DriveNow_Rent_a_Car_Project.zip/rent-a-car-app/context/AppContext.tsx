import React, {createContext, useContext, useState} from 'react';
import {Car} from '../data/cars';
type Booking = {car: Car; date: string};
type ContextType = {user:string|null; login:(name:string)=>void; logout:()=>void; favorites:string[]; toggleFavorite:(id:string)=>void; bookings:Booking[]; addBooking:(car:Car)=>void};
const AppContext = createContext<ContextType | null>(null);
export function AppProvider({children}:{children:React.ReactNode}) {
 const [user,setUser]=useState<string|null>(null);
 const [favorites,setFavorites]=useState<string[]>([]);
 const [bookings,setBookings]=useState<Booking[]>([]);
 const login=(name:string)=>setUser(name.trim()||'Alex Morgan');
 const logout=()=>setUser(null);
 const toggleFavorite=(id:string)=>setFavorites(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]);
 const addBooking=(car:Car)=>setBookings(old=>old.some(x=>x.car.id===car.id)?old:[...old,{car,date:'Today · Flexible pickup'}]);
 return <AppContext.Provider value={{user,login,logout,favorites,toggleFavorite,bookings,addBooking}}>{children}</AppContext.Provider>;
}
export function useApp(){const value=useContext(AppContext);if(!value)throw new Error('AppProvider is missing');return value;}
