export type Car = {
  id: string; name: string; brand: string; category: string; price: number;
  rating: string; seats: number; transmission: string; fuel: string; image: string; tag?: string;
};
export const CARS: Car[] = [
 {id:'1',name:'Model 3',brand:'Tesla',category:'Electric',price:89,rating:'4.9',seats:5,transmission:'Automatic',fuel:'Electric',tag:'POPULAR',image:'https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=1000'},
 {id:'2',name:'C-Class',brand:'Mercedes-Benz',category:'Luxury',price:110,rating:'4.8',seats:5,transmission:'Automatic',fuel:'Petrol',image:'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=1000'},
 {id:'3',name:'911 Carrera',brand:'Porsche',category:'Sports',price:190,rating:'5.0',seats:2,transmission:'Automatic',fuel:'Petrol',tag:'PREMIUM',image:'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1000'},
 {id:'4',name:'Range Rover',brand:'Land Rover',category:'SUV',price:145,rating:'4.9',seats:5,transmission:'Automatic',fuel:'Diesel',image:'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=1000'},
 {id:'5',name:'Mustang GT',brand:'Ford',category:'Sports',price:125,rating:'4.7',seats:4,transmission:'Automatic',fuel:'Petrol',image:'https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd?w=1000'},
 {id:'6',name:'Civic',brand:'Honda',category:'Sedan',price:55,rating:'4.6',seats:5,transmission:'Automatic',fuel:'Petrol',image:'https://images.unsplash.com/photo-1590362891991-f776e747a588?w=1000'}
];
