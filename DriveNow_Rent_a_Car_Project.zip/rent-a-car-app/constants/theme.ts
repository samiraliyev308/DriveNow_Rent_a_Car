export const C = {
  bg: '#101114', panel: '#191B20', panel2: '#22252B', text: '#F7F7F5',
  muted: '#92969F', accent: '#FFC928', line: '#2B2E35', white: '#FFFFFF',
  green: '#7DD3A7', red: '#FF7777'
};
