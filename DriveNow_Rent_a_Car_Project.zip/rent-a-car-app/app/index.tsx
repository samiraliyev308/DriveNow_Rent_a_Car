import React from 'react';
import {View,Text,ImageBackground,StyleSheet,Pressable} from 'react-native';
import {StatusBar} from 'expo-status-bar';
import {router} from 'expo-router';
import {C} from '../constants/theme';
export default function Launch(){
 return <ImageBackground source={{uri:'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1400'}} style={s.bg} resizeMode="cover">
  <StatusBar style="light"/><View style={s.shade}/>
  <View style={s.top}><Text style={s.logo}>DRIVE<Text style={{color:C.accent}}>NOW</Text></Text><Text style={s.pill}>PREMIUM CAR RENTAL</Text></View>
  <View style={s.bottom}><Text style={s.eyebrow}>YOUR JOURNEY STARTS HERE</Text><Text style={s.title}>Drive the{ '\n'}extraordinary.</Text><Text style={s.sub}>Find the perfect car for every road, every plan, every moment.</Text>
   <Pressable style={s.btn} onPress={()=>router.push('/auth')}><Text style={s.btnText}>Get started</Text><Text style={s.arrow}>↗</Text></Pressable>
   <Text style={s.foot}>FREEDOM ON FOUR WHEELS</Text>
  </View>
 </ImageBackground>
}
const s=StyleSheet.create({bg:{flex:1,backgroundColor:C.bg},shade:{...StyleSheet.absoluteFillObject,backgroundColor:'rgba(5,6,8,0.48)'},top:{paddingTop:70,paddingHorizontal:26},logo:{color:C.text,fontSize:25,fontWeight:'900',letterSpacing:2},pill:{color:C.accent,fontSize:10,letterSpacing:2,marginTop:10,fontWeight:'700'},bottom:{marginTop:'auto',padding:26,paddingBottom:55},eyebrow:{color:C.accent,fontSize:10,fontWeight:'800',letterSpacing:2},title:{color:C.text,fontSize:53,fontWeight:'900',lineHeight:57,marginTop:13,letterSpacing:-1.5},sub:{color:'#D1D2D5',fontSize:15,lineHeight:23,marginTop:15,maxWidth:300},btn:{backgroundColor:C.accent,borderRadius:16,paddingHorizontal:20,paddingVertical:18,marginTop:30,flexDirection:'row',alignItems:'center',justifyContent:'space-between'},btnText:{color:'#111',fontWeight:'900',fontSize:16},arrow:{color:'#111',fontSize:22,fontWeight:'800'},foot:{color:'#A7A9AF',fontSize:9,letterSpacing:2,textAlign:'center',marginTop:25}});
