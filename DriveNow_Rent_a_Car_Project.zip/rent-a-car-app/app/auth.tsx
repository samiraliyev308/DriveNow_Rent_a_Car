import React,{useState} from 'react';
import {View,Text,TextInput,Pressable,StyleSheet,KeyboardAvoidingView,Platform,Alert} from 'react-native';
import {router} from 'expo-router';
import {useApp} from '../context/AppContext';
import {C} from '../constants/theme';
export default function Auth(){
 const [mode,setMode]=useState<'login'|'register'>('login'); const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
 const {login}=useApp();
 const submit=()=>{if(!email.trim()||!password.trim()){Alert.alert('Missing details','Enter your email and password to continue.');return;}if(mode==='register'&&!name.trim()){Alert.alert('Your name','Please enter your name.');return;}login(name||email.split('@')[0]);router.replace('/(tabs)');};
 return <KeyboardAvoidingView style={s.root} behavior={Platform.OS==='ios'?'padding':undefined}><Pressable onPress={()=>router.back()}><Text style={s.back}>←  Back</Text></Pressable>
 <View style={s.content}><Text style={s.logo}>DRIVE<Text style={{color:C.accent}}>NOW</Text></Text><Text style={s.title}>{mode==='login'?'Welcome back.':'Create account.'}</Text><Text style={s.sub}>{mode==='login'?'Sign in and get back on the road.':'Join us and find your next ride.'}</Text>
 <View style={s.switch}><Pressable onPress={()=>setMode('login')} style={[s.switchItem,mode==='login'&&s.active]}><Text style={[s.switchText,mode==='login'&&s.activeText]}>Login</Text></Pressable><Pressable onPress={()=>setMode('register')} style={[s.switchItem,mode==='register'&&s.active]}><Text style={[s.switchText,mode==='register'&&s.activeText]}>Register</Text></Pressable></View>
 {mode==='register'&&<TextInput value={name} onChangeText={setName} placeholder="Full name" placeholderTextColor={C.muted} style={s.input}/>}
 <TextInput value={email} onChangeText={setEmail} placeholder="Email address" placeholderTextColor={C.muted} autoCapitalize="none" keyboardType="email-address" style={s.input}/>
 <TextInput value={password} onChangeText={setPassword} placeholder="Password" placeholderTextColor={C.muted} secureTextEntry style={s.input}/>
 <Pressable style={s.button} onPress={submit}><Text style={s.buttonText}>{mode==='login'?'Sign in':'Create account'}</Text><Text style={s.arrow}>↗</Text></Pressable>
 <Text style={s.note}>Demo authentication · no real account or server required</Text>
 </View></KeyboardAvoidingView>
}
const s=StyleSheet.create({root:{flex:1,backgroundColor:C.bg,padding:24,paddingTop:60},back:{color:C.muted,fontSize:15},content:{flex:1,justifyContent:'center'},logo:{fontSize:22,color:C.text,fontWeight:'900',letterSpacing:2},title:{fontSize:38,color:C.text,fontWeight:'900',marginTop:36},sub:{color:C.muted,fontSize:14,marginTop:8,marginBottom:28},switch:{flexDirection:'row',backgroundColor:C.panel,padding:5,borderRadius:13,marginBottom:22},switchItem:{flex:1,padding:12,alignItems:'center',borderRadius:10},active:{backgroundColor:C.accent},switchText:{color:C.muted,fontWeight:'700'},activeText:{color:'#111'},input:{backgroundColor:C.panel,borderWidth:1,borderColor:C.line,borderRadius:13,padding:17,color:C.text,marginBottom:13,fontSize:15},button:{backgroundColor:C.accent,borderRadius:14,padding:18,marginTop:10,flexDirection:'row',justifyContent:'space-between'},buttonText:{fontWeight:'900',color:'#111',fontSize:16},arrow:{color:'#111',fontSize:20},note:{color:C.muted,fontSize:11,textAlign:'center',marginTop:22}});
