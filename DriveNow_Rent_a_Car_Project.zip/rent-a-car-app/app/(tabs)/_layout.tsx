import React from 'react';
import {Tabs} from 'expo-router';
import {Ionicons} from '@expo/vector-icons';
import {C} from '../../constants/theme';
export default function TabLayout(){return <Tabs screenOptions={{headerShown:false,tabBarStyle:{backgroundColor:'#17191E',borderTopColor:C.line,height:82,paddingTop:9,paddingBottom:20},tabBarActiveTintColor:C.accent,tabBarInactiveTintColor:'#777C86',tabBarLabelStyle:{fontSize:10,fontWeight:'700',marginTop:2}}}>
 <Tabs.Screen name="index" options={{title:'Home',tabBarIcon:({color,size})=><Ionicons name="home" color={color} size={size}/>}}/>
 <Tabs.Screen name="explore" options={{title:'Explore',tabBarIcon:({color,size})=><Ionicons name="search" color={color} size={size}/>}}/>
 <Tabs.Screen name="bookings" options={{title:'Bookings',tabBarIcon:({color,size})=><Ionicons name="calendar" color={color} size={size}/>}}/>
 <Tabs.Screen name="profile" options={{title:'Profile',tabBarIcon:({color,size})=><Ionicons name="person" color={color} size={size}/>}}/>
 </Tabs>}
