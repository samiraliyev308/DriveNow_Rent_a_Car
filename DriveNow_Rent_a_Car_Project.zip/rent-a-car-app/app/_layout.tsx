import React from 'react';
import {Stack} from 'expo-router';
import {StatusBar} from 'expo-status-bar';
import {AppProvider} from '../context/AppContext';
import {C} from '../constants/theme';
export default function RootLayout(){return <AppProvider><StatusBar style="light"/><Stack screenOptions={{headerShown:false,contentStyle:{backgroundColor:C.bg}}}><Stack.Screen name="index"/><Stack.Screen name="auth"/><Stack.Screen name="(tabs)"/><Stack.Screen name="car/[id]" options={{presentation:'card'}}/></Stack></AppProvider>}
